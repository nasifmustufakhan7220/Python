food = input("What is your favorite food?\n")

print("Wow I also like " + food)