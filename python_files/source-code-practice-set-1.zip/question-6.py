a = int(input("Enter first number\n"))
b = int(input("Enter second number\n"))

print("a + b is ", a + b)
print("a - b is ", a - b)
print("a * b is ", a * b)
print("a / b is ", a / b)