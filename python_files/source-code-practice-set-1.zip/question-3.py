name = "Shivani"
age = 19
height = 160.4
is_student = True

print("The name of the student is " + name + ". She is " + str(age) + " years old. " + "She is " + str(height) + " cms tall. " + "Student: " + str(is_student))