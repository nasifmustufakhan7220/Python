a = int(input("Enter your number \n" ))

print("Square is", a**2)
print("Cube is", a**3)