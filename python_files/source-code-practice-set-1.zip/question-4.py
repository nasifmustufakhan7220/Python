num = "45"
print(int(num) + 10)